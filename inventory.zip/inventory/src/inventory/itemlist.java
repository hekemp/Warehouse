package inventory;

public class itemlist {

}
