package inventory;

public class item {
	String type;      
	int itemID;       //Each item has an unique itemID
	int minprefered;  //minmmum amount of this item 
	boolean ordered;
	
	item(int id){
		itemID=id;
	}


	
	

}
